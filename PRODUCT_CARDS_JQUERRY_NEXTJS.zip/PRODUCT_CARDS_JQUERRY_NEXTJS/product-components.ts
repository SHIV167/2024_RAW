// src/components/ProductCard.tsx
import Image from 'next/image';
import { Product } from '@prisma/client';

interface ProductCardProps {
  product: Product & { category: { name: string } };
  onAddToCart: (productId: number) => void;
  onBuyNow: (product: Product) => void;
}

export default function ProductCard({ product, onAddToCart, onBuyNow }: ProductCardProps) {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden">
      <div className="relative h-48 w-full">
        <Image
          src={product.imageUrl || '/placeholder.png'}
          alt={product.title}
          fill
          className="object-cover"
        />
      </div>
      <div className="p-4">
        <h3 className="text-lg font-semibold truncate">{product.title}</h3>
        <p className="text-gray-600 text-sm mt-1 line-clamp-2">
          {product.description}
        </p>
        <div className="mt-2">
          <span className="text-sm text-gray-500">
            {product.category.name}
          </span>
        </div>
        <div className="mt-4 flex items-center justify-between">
          <span className="text-xl font-bold">
            ${product.price.toFixed(2)}
          </span>
          <div className="space-x-2">
            <button
              onClick={() => onAddToCart(product.id)}
              className="px-3 py-1 bg-indigo-600 text-white rounded hover:bg-indigo-700"
            >
              Add to Cart
            </button>
            <button
              onClick={() => onBuyNow(product)}
              className="px-3 py-1 bg-green-600 text-white rounded hover:bg-green-700"
            >
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// src/components/ProductGrid.tsx
'use client';

import { useState, useEffect } from 'react';
import ProductCard from './ProductCard';
import { Product } from '@prisma/client';
import ProductFilters from './ProductFilters';

export default function ProductGrid() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    search: '',
    category: 'all',
    minPrice: '',
    maxPrice: '',
  });

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      Object.entries(filters).forEach(([key, value]) => {
        if (value) params.append(key, value.toString());
      });

      const response = await fetch(`/api/products?${params}`);
      const data = await response.json();
      setProducts(data.products);
    } catch (error) {
      console.error('Error fetching products:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, [filters]);

  const handleAddToCart = async (productId: number) => {
    try {
      // Add to cart logic here
      alert('Added to cart!');
    } catch (error) {
      console.error('Error adding to cart:', error);
    }
  };

  const handleBuyNow = (product: Product) => {
    // Implement buy now logic
    alert('Buy now clicked!');
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <ProductFilters
        filters={filters}
        onFilterChange={setFilters}
      />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mt-8">
        {products.map((product) => (
          <ProductCard
            key={product.id}
            product={product}
            onAddToCart={handleAddToCart}
            onBuyNow={handleBuyNow}
          />
        ))}
      </div>
    </div>
  );
}

// src/components/ProductFilters.tsx
'use client';

import { useCallback } from 'react';
import PriceRangeSlider from './PriceRangeSlider';

interface Filters {
  search: string;
  category: string;
  minPrice: string;
  maxPrice: string;
}

interface ProductFiltersProps {
  filters: Filters;
  onFilterChange: (filters: Filters) => void;
}

export default function ProductFilters({
  filters,
  onFilterChange,
}: ProductFiltersProps) {
  const handleInputChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      const { name, value } = e.target;
      onFilterChange({ ...filters, [name]: value });
    },
    [filters, onFilterChange]
  );

  const handlePriceChange = useCallback(
    (min: string, max: string) => {
      onFilterChange({
        ...filters,
        minPrice: min,
        maxPrice: max,
      });
    },
    [filters, onFilterChange]
  );

  return (
    <div className="bg-white p-4 rounded-lg shadow">
      <input
        type="text"
        name="search"
        placeholder="Search products..."
        value={filters.search}
        onChange={handleInputChange}
        className="w-full p-2 border rounded mb-4"
      />
      <select
        name="category"
        value={filters.category}
        onChange={handleInputChange}
        className="w-full p-2 border rounded mb-4"
      >
        <option value="all">All Categories</option>
        {/* Add categories dynamically */}
      </select>
      <PriceRangeSlider
        min={filters.minPrice}
        max={filters.maxPrice}
        onChange={handlePriceChange}
      />
    </div>
  );
}
