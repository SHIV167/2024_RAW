// Project structure with key files:

src/
├── app/
│   ├── layout.tsx
│   ├── page.tsx
│   └── products/
│       └── page.tsx
├── components/
│   ├── ProductCard.tsx
│   ├── ProductGrid.tsx
│   ├── ProductFilters.tsx
│   └── PriceRangeSlider.tsx
├── lib/
│   ├── prisma.ts
│   └── utils.ts
└── app/
    └── api/
        ├── products/
        │   └── route.ts
        └── categories/
            └── route.ts
