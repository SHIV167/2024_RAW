<?php
// api/products.php
require_once '../config.php';

// Handle CORS
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$method = $_SERVER['REQUEST_METHOD'];
$conn = getDBConnection();

switch($method) {
    case 'GET':
        getProducts();
        break;
    case 'POST':
        addProduct();
        break;
    case 'PUT':
        updateProduct();
        break;
    case 'DELETE':
        deleteProduct();
        break;
    default:
        jsonResponse(['error' => 'Method not allowed'], 405);
}

function getProducts() {
    global $conn;
    
    try {
        // Get filter parameters
        $category = isset($_GET['category']) ? sanitize($_GET['category']) : null;
        $minPrice = isset($_GET['minPrice']) ? floatval($_GET['minPrice']) : null;
        $maxPrice = isset($_GET['maxPrice']) ? floatval($_GET['maxPrice']) : null;
        $search = isset($_GET['search']) ? sanitize($_GET['search']) : null;
        
        // Build query
        $query = "SELECT * FROM products WHERE 1=1";
        $params = [];
        
        if ($category && $category !== 'all') {
            $query .= " AND category = ?";
            $params[] = $category;
        }
        
        if ($minPrice !== null) {
            $query .= " AND price >= ?";
            $params[] = $minPrice;
        }
        
        if ($maxPrice !== null) {
            $query .= " AND price <= ?";
            $params[] = $maxPrice;
        }
        
        if ($search) {
            $query .= " AND (title LIKE ? OR description LIKE ?)";
            $params[] = "%$search%";
            $params[] = "%$search%";
        }
        
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        jsonResponse($products);
    } catch(PDOException $e) {
        jsonResponse(['error' => $e->getMessage()], 500);
    }
}

function addProduct() {
    global $conn;
    
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        // Validate required fields
        $required = ['title', 'price', 'category'];
        foreach ($required as $field) {
            if (!isset($data[$field])) {
                jsonResponse(['error' => "Missing required field: $field"], 400);
            }
        }
        
        $stmt = $conn->prepare("
            INSERT INTO products (title, description, price, category, image_url)
            VALUES (?, ?, ?, ?, ?)
        ");
        
        $stmt->execute([
            sanitize($data['title']),
            sanitize($data['description'] ?? ''),
            floatval($data['price']),
            sanitize($data['category']),
            sanitize($data['image_url'] ?? '')
        ]);
        
        jsonResponse(['message' => 'Product added successfully', 'id' => $conn->lastInsertId()]);
    } catch(PDOException $e) {
        jsonResponse(['error' => $e->getMessage()], 500);
    }
}

function updateProduct() {
    global $conn;
    
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['id'])) {
            jsonResponse(['error' => 'Product ID is required'], 400);
        }
        
        $fields = [];
        $params = [];
        
        // Build dynamic update query
        foreach (['title', 'description', 'price', 'category', 'image_url'] as $field) {
            if (isset($data[$field])) {
                $fields[] = "$field = ?";
                $params[] = sanitize($data[$field]);
            }
        }
        
        if (empty($fields)) {
            jsonResponse(['error' => 'No fields to update'], 400);
        }
        
        $params[] = $data['id'];
        $query = "UPDATE products SET " . implode(', ', $fields) . " WHERE id = ?";
        
        $stmt = $conn->prepare($query);
        $stmt->execute($params);
        
        jsonResponse(['message' => 'Product updated successfully']);
    } catch(PDOException $e) {
        jsonResponse(['error' => $e->getMessage()], 500);
    }
}

function deleteProduct() {
    global $conn;
    
    try {
        $data = json_decode(file_get_contents('php://input'), true);
        
        if (!isset($data['id'])) {
            jsonResponse(['error' => 'Product ID is required'], 400);
        }
        
        $stmt = $conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$data['id']]);
        
        jsonResponse(['message' => 'Product deleted successfully']);
    } catch(PDOException $e) {
        jsonResponse(['error' => $e->getMessage()], 500);
    }
}
