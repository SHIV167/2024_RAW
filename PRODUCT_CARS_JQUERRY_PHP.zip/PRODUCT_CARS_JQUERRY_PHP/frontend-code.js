$(document).ready(function () {
    let allProducts = [];
    let activeFilters = {
        search: '',
        minPrice: '',
        maxPrice: '',
        category: 'all',
        sort: 'default'
    };
    let currentPage = 1;
    const productsPerPage = 6;
    let priceSlider;

    // Modified fetchProducts function to work with PHP backend
    function fetchProducts() {
        // Build query string based on active filters
        const queryParams = new URLSearchParams();
        if (activeFilters.search) queryParams.append('search', activeFilters.search);
        if (activeFilters.minPrice) queryParams.append('minPrice', activeFilters.minPrice);
        if (activeFilters.maxPrice) queryParams.append('maxPrice', activeFilters.maxPrice);
        if (activeFilters.category !== 'all') queryParams.append('category', activeFilters.category);

        $.ajax({
            url: 'api/products.php?' + queryParams.toString(),
            method: 'GET',
            success: function (products) {
                allProducts = products;

                // Sort products if needed
                if (activeFilters.sort !== 'default') {
                    sortProducts();
                }

                // Initialize price slider if it hasn't been initialized yet
                if (!priceSlider) {
                    const minPrice = Math.floor(Math.min(...products.map(p => p.price)));
                    const maxPrice = Math.ceil(Math.max(...products.map(p => p.price)));
                    initializePriceSlider(minPrice, maxPrice);
                }

                displayProducts(allProducts);
                initializeCategories(products);
            },
            error: function (xhr, status, error) {
                $('#products-container').html(`
                    <div class="error-message">
                        Error loading products: ${error}
                    </div>
                `);
            }
        });
    }

    // Add new product function
    function addProduct(productData) {
        $.ajax({
            url: 'api/products.php',
            method: 'POST',
            contentType: 'application/json',
            data: JSON.stringify(productData),
            success: function(response) {
                alert('Product added successfully!');
                fetchProducts(); // Refresh the product list
            },
            error: function(xhr, status, error) {
                alert('Error adding product: ' + error);
            }
        });
    }

    // Update product function
    function updateProduct(productData) {
        $.ajax({
            url: 'api/products.php',
            method: 'PUT',
            contentType: 'application/json',
            data: JSON.stringify(productData),
            success: function(response) {
                alert('Product updated successfully!');
                fetchProducts(); // Refresh the product list
            },
            error: function(xhr, status, error) {
                alert('Error updating product: ' + error);
            }
        });
    }

    // Delete product function
    function deleteProduct(productId) {
        if (confirm('Are you sure you want to delete this product?')) {
            $.ajax({
                url: 'api/products.php',
                method: 'DELETE',
                contentType: 'application/json',
                data: JSON.stringify({ id: productId }),
                success: function(response) {
                    alert('Product deleted successfully!');
                    fetchProducts(); // Refresh the product list
                },
                error: function(xhr, status, error) {
                    alert('Error deleting product: ' + error);
                }
            });
        }
    }

    // Sort products function
    function sortProducts() {
        switch (activeFilters.sort) {
            case 'price-low':
                allProducts.sort((a, b) => a.price - b.price);
                break;
            case 'price-high':
                allProducts.sort((a, b) => b.price - a.price);
                break;
            case 'name':
                allProducts.sort((a, b) => a.title.localeCompare(b.title));
                break;
        }
    }

    // Rest of the functions remain the same as in your original code
    // (initializePriceSlider, createProductCard, updateProductsCount, displayProducts, etc.)

    // Modified event listeners to trigger API calls
    $('.search-box').on('input', function() {
        activeFilters.search = $(this).val();
        fetchProducts();
    });

    $(document).on('click', '.category-btn', function() {
        $('.category-btn').removeClass('active');
        $(this).addClass('active');
        activeFilters.category = $(this).data('category');
        fetchProducts();
    });

    $('.sort-select').on('change', function() {
        activeFilters.sort = $(this).val();
        fetchProducts();
    });

    // Initial load
    fetchProducts();
});
