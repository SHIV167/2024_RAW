const profileCardTemplate = document.getElementById(
  "profile-card-template"
).content;
const profileCardsContainer = document.getElementById(
  "profile-cards-container"
);

// Function to create profile cards
function createProfileCard(pictureUrl, name, jobTitle, description) {
  const clone = document.importNode(profileCardTemplate, true);
  const profilePicture = clone.querySelector(".profile-picture");
  const profileTitle = clone.querySelector(".profile-title");
  const profileJobTitle = clone.querySelector(".profile-job-title");
  const profileDescription = clone.querySelector(".profile-description");

  profilePicture.src = pictureUrl;
  profileTitle.textContent = name;
  profileJobTitle.textContent = jobTitle;
  profileDescription.textContent = description;
  profileCardsContainer.appendChild(clone);
}

// Example profile data
const profiles = [
  {
    pictureUrl: "img/new_user.jpg",
    name: "Edna Joseph",
    jobTitle: "Software Engineer",
    description: "Experienced in developing scalable web applications.",
  },
  {
    pictureUrl: "img/peter_kelechi.jpg",
    name: "Peter Kelechi",
    jobTitle: "Product Manager",
    description: "Guides product vision, strategy, and success.",
  },
  {
    pictureUrl: "img/grace_franklin.jpg",
    name: "Grace Franklin",
    jobTitle: "UX Designer",
    description: "Passionate about creating user-friendly designs.",
  },
];

// Create profile cards based on profile data
profiles.forEach((profile) =>
  createProfileCard(
    profile.pictureUrl,
    profile.name,
    profile.jobTitle,
    profile.description
  )
);
