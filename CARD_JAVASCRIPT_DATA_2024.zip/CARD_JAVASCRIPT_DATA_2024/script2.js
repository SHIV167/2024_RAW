const blogPostTemplate = document.getElementById("blog-post-template").content;
const blogPostContainer = document.getElementById("blog-post-container");

// Function to create a blog post
function createBlogPost(title, author, date, content) {
  const clone = document.importNode(blogPostTemplate, true);
  const blogTitle = clone.querySelector("h2");
  const blogAuthor = clone.querySelector(".author");
  const blogDate = clone.querySelector(".date");
  const blogContent = clone.querySelector(".content");

  blogTitle.textContent = title;
  blogAuthor.textContent = author;
  blogDate.textContent = date;
  blogContent.innerHTML = content;
  blogPostContainer.appendChild(clone);
}

// Example blog post data
const blogPosts = [
  {
    title: "How to Build a Reusable Component in HTML",
    author: "Chiamaka David",
    date: "April 15, 2024",
    content: "<p>Building reusable components in HTML...</p>",
  },
  {
    title: "Top 10 JavaScript Frameworks in 2024",
    author: "Solomon Daniels",
    date: "June 12, 2024",
    content: "<p>JavaScript frameworks continue to dominate...</p>",
  },
  {
    title: "Understanding CSS Flexbox",
    author: "Samuel Grant",
    date: "March 10, 2024",
    content: "<p>Flexbox is a powerful tool in CSS...</p>",
  },
];

// Create blog posts based on the blog post data
blogPosts.forEach((post) =>
  createBlogPost(post.title, post.author, post.date, post.content)
);
